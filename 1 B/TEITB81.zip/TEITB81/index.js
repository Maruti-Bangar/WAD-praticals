const button = document.getElementById('button')
const submitHandler = () => {
    const name = document.getElementById('name').value;
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    let details = `'{ "details" : ['
    '{ "Name":${name} , "usename":${username},"email":${email},"password",${password} }
     ]}'`;
    
     $.ajax({
        url:'http://127.0.0.1:5500\details.php',
        data:{name:name,email:email,password:password,username:username},
        type:'POST'
     }).done(function(resp){
        localStorage.clear()
        localStorage.setItem("details",details);
            alert(resp);
            console.log(resp)
     })
     
}

button.addEventListener('click', submitHandler)

