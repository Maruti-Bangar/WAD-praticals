<?php
$name = !empty($_POST['name']) ? $_POST['name'] : false;

$email = !empty($_POST['email']) ? $_POST['email'] : false;
$password = !empty($_POST['password']) ? $_POST['password'] : false;

$username = !empty($_POST['userName']) ? $_POST['userName'] : false;
echo "Hello,{$name}"
if ($username) {
  echo "Hello, {$username}";
}
else {
  echo "Who's there?";
}		
	?>  